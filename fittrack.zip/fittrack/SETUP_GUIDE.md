# FitTrack — Deployment Guide

## What's in this folder

```
fittrack/
├── api/
│   └── generate-workout.js   ← Secure serverless function (hides your API key)
├── public/
│   ├── manifest.json         ← Makes it installable on iPhone home screen
│   └── icon.svg              ← App icon
├── src/
│   ├── main.jsx              ← React entry point
│   └── App.jsx               ← Your full app code
├── index.html
├── package.json
├── vite.config.js
└── vercel.json               ← Vercel routing config
```

---

## Step 1 — Install Node.js
Download and install from https://nodejs.org (choose the LTS version)

---

## Step 2 — Set up the project locally

Open Terminal, navigate to this folder, then run:

```bash
npm install
npm run dev
```

Open http://localhost:5173 — your app should be running locally.

---

## Step 3 — Push to GitHub

1. Create a free account at https://github.com
2. Click "New repository", name it `fittrack`, make it Private
3. In Terminal, inside the fittrack folder run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/fittrack.git
git push -u origin main
```

---

## Step 4 — Deploy to Vercel

1. Create a free account at https://vercel.com
2. Click "Add New Project"
3. Import your `fittrack` GitHub repository
4. Click Deploy — Vercel auto-detects Vite/React

Your app will be live at something like: https://fittrack-xyz.vercel.app

---

## Step 5 — Add your Groq API key securely

This is the important part — your key goes into Vercel, NOT into any code file.

1. In Vercel, open your project dashboard
2. Go to Settings → Environment Variables
3. Add a new variable:
   - Name:  GROQ_API_KEY
   - Value: your actual Groq API key (from console.groq.com)
4. Click Save
5. Go to Deployments → click the 3 dots on your latest deploy → Redeploy

Your API key is now stored securely on Vercel's servers. It never appears
in your code or in the browser. Users cannot find it.

---

## Step 6 — Install on your iPhone (optional)

1. Open your Vercel URL in Safari on your iPhone
2. Tap the Share button (box with arrow pointing up)
3. Tap "Add to Home Screen"
4. Tap "Add"

FitTrack will appear as a full-screen app on your home screen.

---

## Sharing with others

Just send people your Vercel URL (e.g. https://fittrack-xyz.vercel.app).
That's it — they can use it in any browser, or add it to their home screen.

---

## Making updates

Whenever you change your code:
```bash
git add .
git commit -m "describe your change"
git push
```

Vercel automatically redeploys within about 30 seconds. No manual steps needed.

---

## Getting a custom domain (optional)

In Vercel → Settings → Domains, you can add a custom domain like
www.fittrack.app for around $10-15/year from any domain registrar.
